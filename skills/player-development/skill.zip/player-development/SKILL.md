---
name: player-development
description: Create football player development plans from coach observations, position responsibilities, goals, and practice opportunities. Use for individual improvement plans, position coaching notes, rep plans, or progress reviews.
---

# Player Development

Convert observations into 1-3 specific development priorities per player, observable behaviors, drills/reps, coaching cues, and review checkpoints. Keep feedback age-appropriate and constructive. Do not diagnose medical, psychological, or learning conditions. Focus on coach-observable football behaviors.
