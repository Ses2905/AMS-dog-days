---
name: roster-depth-chart-manager
description: Organize football rosters, depth charts, position groups, jersey numbers, availability, eligibility status supplied by the coach, and special-teams assignments. Use when updating personnel plans, producing depth charts, finding conflicts, or planning substitutions.
---

# Roster Depth Chart Manager

Maintain one canonical player record. Preserve supplied school/eligibility decisions rather than making them. Detect duplicate assignments, thin position groups, players assigned to simultaneous special-teams roles, and missing backups. Produce concise depth charts and change summaries. Treat health details as restricted context and minimize unnecessary exposure.
