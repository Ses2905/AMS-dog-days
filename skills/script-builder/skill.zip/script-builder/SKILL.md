---
name: script-builder
description: Create football practice and game scripts for junior-high and high-school teams. Use for team offense/defense, inside run, 7-on-7, red zone, backed-up, two-minute, third down, goal line, special teams, opening scripts, or scout-team scripts.
---

# Script Builder

Create numbered, executable scripts. Ask or infer only when safe: play/call inventory, hash, field position, down-distance, personnel, formation/front, desired situations, and rep count. Balance repetition of priorities with realistic variation. Include a compact coach-notes column and an optional result/grade field for live use.
