---
name: parent-player-comms
description: Draft clear, school-appropriate football communications for players and families. Use for schedule changes, equipment reminders, travel details, practice updates, expectations, recognition, or general team announcements.
---

# Parent Player Comms

Draft concise communication from supplied facts. Put the action/date/time first. Avoid sharing private player information, discipline details, or sensitive family information. When the topic involves policy, eligibility, discipline, transportation, or safety, preserve the school's official language when provided and flag anything requiring administrator confirmation.
