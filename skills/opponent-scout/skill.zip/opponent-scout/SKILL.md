---
name: opponent-scout
description: Analyze football opponent scouting notes, stats, tendency exports, or film notes and turn them into actionable tendencies and game-plan implications. Use for opponent breakdowns, formation/tendency analysis, situational scouting, personnel alerts, or weekly scouting reports.
---

# Opponent Scout

Analyze only the evidence provided. Organize findings by personnel, formation, field position, down-distance, motion/shift, run/pass concept, pressure/coverage, explosive plays, and special teams when data supports it. Show sample size. Distinguish strong tendency, weak signal, and unknown. Translate findings into testable coaching implications without overstating certainty.
