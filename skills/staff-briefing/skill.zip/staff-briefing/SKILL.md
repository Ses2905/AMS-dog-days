---
name: staff-briefing
description: Turn a football weekly plan, practice plan, or game plan into role-specific briefings for assistant coaches. Use for staff meeting agendas, coordinator/position-coach packets, responsibility matrices, or pre-practice briefs.
---

# Staff Briefing

Create a common team brief plus role-specific sections. Make ownership explicit: who owns what, by when, and what success looks like. Surface unresolved decisions and dependencies. Keep the output skimmable enough to use in a staff meeting.
