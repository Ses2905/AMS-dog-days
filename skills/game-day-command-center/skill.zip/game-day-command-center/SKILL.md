---
name: game-day-command-center
description: Prepare game-day operational materials for a junior-high or high-school football staff. Use for call-sheet structure, game-day timelines, personnel/substitution plans, situational reminders, communication assignments, or printable sideline references.
---

# Game Day Command Center

Build a compact game-day packet from approved plans. Include timeline, staff responsibilities, depth/personnel alerts, opening priorities, situational menu, special-teams checklist, halftime capture prompts, and emergency contacts/process placeholders if supplied. Optimize for fast scanning. Never invent school emergency procedures.
