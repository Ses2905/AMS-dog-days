---
name: practice-plan-builder
description: Build timed junior-high and high-school football practice plans from priorities, available minutes, personnel, install needs, and game context. Use for daily practice plans, weekly practice sequencing, period schedules, scout periods, indy/group/team allocation, or practice-plan revisions.
---

# Practice Plan Builder

Build a field-ready practice plan. Capture total minutes, day of week, opponent/game context, install priorities, special teams, position needs, available players, equipment/space constraints, and desired tempo. Allocate every minute. Include period name, duration, groups, objective, setup, coaching emphasis, and transition notes. Flag overloaded plans and recommend what to cut first. End with 3-5 success checks for the head coach.
