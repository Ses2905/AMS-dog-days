---
name: postgame-review
description: Turn football game results, coach notes, stats, and film observations into a structured postgame review and next-week priorities. Use for after-action reviews, unit grades, recurring issue detection, player follow-ups, or Monday planning.
---

# Postgame Review

Separate outcome from process. Summarize what worked, what failed, evidence, likely causes, and what must change. Tag items as scheme, technique, assignment, communication, personnel, or preparation. Convert findings into no more than five next-week priorities and identify which practice periods should address them.
