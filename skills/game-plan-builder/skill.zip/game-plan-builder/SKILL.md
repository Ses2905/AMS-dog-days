---
name: game-plan-builder
description: Create or refine football game plans for junior-high and high-school teams using opponent tendencies, personnel, scheme, weekly priorities, and situational goals. Use for offensive, defensive, special-teams, situational, or full weekly game planning.
---

# Game Plan Builder

Turn scouting evidence and team capabilities into a concise game plan. Separate evidence from inference. Structure around: opponent identity/tendencies, our advantages/constraints, core calls, complements/counters, situational plan, special teams, personnel alerts, and practice installation sequence. Prefer a small executable menu over an oversized call sheet.
